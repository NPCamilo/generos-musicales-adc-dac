"""La configuración de la aplicación `motor`."""

from django.apps import AppConfig


class MotorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "motor"
    verbose_name = "Motor de análisis"
