"""La entrada ASGI (para servidores asíncronos)."""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "dsp_web.settings")

application = get_asgi_application()
